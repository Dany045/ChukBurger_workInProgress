package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class MiaClasse {
	public void Msg_Info(String Titolo, String Header, String Contenuto) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(Titolo);
		alert.setHeaderText(Header);
		alert.setContentText(Contenuto);
		alert.showAndWait();
	}
	public void Msg_Errore(String Titolo, String Header, String Contenuto) {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle(Titolo);
		alert.setHeaderText(Header);
		alert.setContentText(Contenuto);
		alert.showAndWait();
	}
	public void Msg_Warning(String Titolo, String Header, String Contenuto) {
		Alert alert = new Alert(AlertType.WARNING);
		alert.setTitle(Titolo);
		alert.setHeaderText(Header);
		alert.setContentText(Contenuto);
		alert.showAndWait();
	}
	public void scriviFile (String path,String s) {
		try(PrintWriter writer = new PrintWriter( new BufferedWriter(new FileWriter(path,true)))){
			writer.println(s);
			writer.flush();	
		} catch (Exception e) {
			System.out.println("Errore nella scittura del file: "+e.getMessage());
		}
	}
	public void scriviFileB (String path,String s) {
		try(PrintWriter writer = new PrintWriter( new BufferedWriter(new FileWriter(path)))){
			writer.println(s);
			writer.flush();	
		} catch (Exception e) {
			System.out.println("Errore nella scittura del file: "+e.getMessage());
		}
	}
	public void scriviFile1 (String path,String s) {
		try(PrintWriter writer = new PrintWriter( new BufferedWriter(new FileWriter(path,true)))){
			writer.print(s);
			writer.flush();	
		} catch (Exception e) {
			System.out.println("Errore nella scittura del file: "+e.getMessage());
		}
	}
	public void scriviFileB1 (String path,String s) {
		try(PrintWriter writer = new PrintWriter( new BufferedWriter(new FileWriter(path)))){
			writer.print(s);
			writer.flush();	
		} catch (Exception e) {
			System.out.println("Errore nella scittura del file: "+e.getMessage());
		}
	}
	public String leggiFileUltimaRiga (String path) {
		String s="";
		try(BufferedReader read= new BufferedReader(new FileReader(path))) {
			String riga;
			while((riga=read.readLine())!=null) {s=riga;}
		}catch(Exception e) {
			s="";
			System.out.println("⚠️ Errore nella lettura del file:"+e.getMessage());
		}
		return s;
	}
	
}
