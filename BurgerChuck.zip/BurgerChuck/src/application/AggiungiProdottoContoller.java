package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class AggiungiProdottoContoller {
	@FXML
    private TextField Nome;

    @FXML
    private TextField PercorsoImg;

    @FXML
    private TextField Prezzo;

    @FXML
    private ComboBox<String> cmbTipo;

    @FXML
    private TextField Calorie;
    
    @FXML
    private VBox campiAggiuntivi;
    
    private TextField Ingredienti;
    private TextField Peso;
    private TextField Capacita;
    private File fileSelezionato = null;
    private MiaClasse cl = new MiaClasse();
    
    @FXML
    void annulla(ActionEvent event) {
        chiudiFinestra(event);
    }

    private void chiudiFinestra(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    @FXML
    void cambiaTipo(ActionEvent event) {
         String tipo= cmbTipo.getValue();
         campiAggiuntivi.getChildren().clear();
         if(tipo==null) return;
         if(tipo.equalsIgnoreCase("Panino")) {
        	 Ingredienti=new TextField();
        	 Ingredienti.setPromptText("Es: Cipolle, Bacon ....");
        	 Peso = new TextField();
             Peso.setPromptText("Es: 10.00");
             
             campiAggiuntivi.getChildren().addAll(
                     new Label("Ingredienti:"), Ingredienti,
                     new Label("Peso (g):"), Peso
                 );
         }else if(tipo.equalsIgnoreCase("Bibita")) {
        	 Capacita = new TextField();
             Capacita.setPromptText("Es: 0.33");

             campiAggiuntivi.getChildren().addAll(
                 new Label("Capacità (L):"), Capacita
             );
         }else if(tipo.equalsIgnoreCase("Sfiziosita")) {
        	 Peso = new TextField();
             Peso.setPromptText("Es: 250");

             campiAggiuntivi.getChildren().addAll(
                 new Label("Peso (g):"), Peso
             );
         }
    }

    @FXML
    void salvaProdotto(ActionEvent event) {
    	String tipo = cmbTipo.getValue();
        String nome = Nome.getText().trim();
        String prezzoStr = Prezzo.getText().trim();
        String calorieStr = Calorie.getText().trim();
        if (tipo == null || nome.isEmpty() || prezzoStr.isEmpty() || calorieStr.isEmpty() || fileSelezionato == null) {
            cl.Msg_Info("Errore", "Campi incompleti", "Compila tutti i campi e seleziona un'immagine!");
            return;
        }
        if(leggiFileNome("prodotti.txt",nome)) {
        	cl.Msg_Info("Errore", "Nome prodotto già presente", "Non puoi inserire un prodotto con un nome già presente nel menu!!");
            return;
        }
        try {
            double prezzo = Double.parseDouble(prezzoStr);
            int calorie = Integer.parseInt(calorieStr);
            String pathF = "Img/" + fileSelezionato.getName();
            File pathBin = new File("bin/application/Img");
            if (!pathBin.exists()) pathBin.mkdirs();
            File destBin = new File(pathBin, fileSelezionato.getName());
            Files.copy(fileSelezionato.toPath(), destBin.toPath(), StandardCopyOption.REPLACE_EXISTING);
            File pathSrc = new File("src/application/Img");
            if (!pathSrc.exists()) pathSrc.mkdirs();
            File destSrc = new File(pathSrc, fileSelezionato.getName());
            Files.copy(fileSelezionato.toPath(), destSrc.toPath(), StandardCopyOption.REPLACE_EXISTING);
            String rigaTxt = "";
            if (tipo.equalsIgnoreCase("Panino")) {
                String ingr = Ingredienti.getText().trim();
                int peso = Integer.parseInt(Peso.getText().trim());
                rigaTxt = "panino;" + nome + ";" + prezzo + ";" + calorie + ";" + pathF + ";" + ingr + ";" + peso;
            } else if (tipo.equalsIgnoreCase("Bibita")) {
                double cap = Double.parseDouble(Capacita.getText().trim());
                rigaTxt = "bibita;" + nome + ";" + prezzo + ";" + calorie + ";" + pathF + ";" + cap;
            } else if (tipo.equalsIgnoreCase("Sfiziosita")) {
                int peso = Integer.parseInt(Peso.getText().trim());
                rigaTxt = "sfiziosita;" + nome + ";" + prezzo + ";" + calorie + ";" + pathF + ";" + peso;
            }
            cl.scriviFile("prodotti.txt", rigaTxt);
            cl.Msg_Info("Successo", "Prodotto Salvato", "Il prodotto è stato aggiunto con successo nel menu.");
            chiudiFinestra(event);

        } catch (NumberFormatException e) {
            cl.Msg_Info("Errore Formato", "Dati Numerici Errati", "Controlla di aver inserito numeri corretti in Prezzo, Calorie o Peso/Capacità!");
        } catch (IOException e) {
            cl.Msg_Info("Errore File", "Impossibile salvare l'immagine", "Si è verificato un problema nel copiare il file nella cartella");
            e.printStackTrace();
        }
    }
    
    public boolean leggiFileNome (String path,String n) {
		try(BufferedReader read= new BufferedReader(new FileReader(path))) {
			String riga;
			while((riga=read.readLine())!=null) {
               String[] campo=riga.split(";");
               if(campo[1].trim().equalsIgnoreCase(n)) return true;
			}
		}catch(Exception e) {
			System.out.println("⚠️ Errore nella lettura del file:"+e.getMessage());
		}
		return false;
	}

    @FXML
    void selezionaImmagine(ActionEvent event) {
    	FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Immagini (*.png, *.jpg, *.jpeg)", "*.png", "*.jpg", "*.jpeg"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        fileSelezionato = fc.showOpenDialog(stage);
        if (fileSelezionato != null)  PercorsoImg.setText(fileSelezionato.getName());
    }
    
    @FXML
    void initialize() {
        cmbTipo.setItems(FXCollections.observableArrayList("Panino", "Bibita", "Sfiziosita"));
    }
}
