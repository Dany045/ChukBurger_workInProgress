package application;

public class ItemCart {
     private Prodotto p;
     private int qta;
     
	 public ItemCart(Prodotto p, int qta) {
		this.p = p;
		this.qta = qta;
	 }

	 public int getQta() {
		 return qta;
	 }

	 public void setQta(int qta) {
		 this.qta = qta;
	 }

	 public Prodotto getP() {
		 return p;
	 }

	 public void setP(Prodotto p) {
		 this.p = p;
	 }
	 
	 public double getTotaleI() {
	        return p.getPrezzo() * qta;
	    }
     
     
}
