package application;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Ordine {
	private Carrello carrello;
    private LocalDateTime tempo;
    private int nOrdine;
    
    public Ordine() {}
	public Ordine(Carrello carrello, LocalDateTime tempo, int nOrdine) {
		this.carrello = carrello;
		this.tempo = tempo;
		this.nOrdine = nOrdine;
	}
	
	public Carrello getCarrello() {
		return carrello;
	}
	public void setCarrello(Carrello carrello) {
		this.carrello = carrello;
	}
	public LocalDateTime getTempo() {
		return tempo;
	}
	public void setTempo(LocalDateTime tempo) {
		this.tempo = tempo;
	}
	public int getnOrdine() {
		return nOrdine;
	}
	public void setnOrdine(int nOrdine) {
		this.nOrdine = nOrdine;
	}
	public String toString () {
		String s="Ordine "+nOrdine+"\n";
		for (ItemCart i:carrello.getElenco()) {
			s+=i.getQta()+"x  "+i.getP().getNome()+"    "+i.getTotaleI()+"�"+"\n";
		}
		s+=tempo+"\n--------------------------";
		return s;
	}
	public String scontrino() {
	    String sb = "=================================\n     BURGER CHUCK      \n=================================\n";
	    sb += "Ordine N�: " + nOrdine + "\n";
	    sb += "Data: " + tempo.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")) + "\n";
	    sb += "---------------------------------\n";
	    
	    for (ItemCart item : carrello.getElenco()) {
	        sb += String.format("%-18s x%-2d  �%6.2f\n", 
	            item.getP().getNome(), 
	            item.getQta(), 
	            item.getTotaleI());
	    } sb += "---------------------------------\n";
	    sb += String.format("TOTALE :       �%6.2f\n", carrello.getPrezzo());
	    sb += "=================================\n    Grazie e Buon Appetito!      \n=================================\n";
	    return sb;
	}
    
    
    
    
}
