package application;

import java.util.ArrayList;

public class Carrello {
     private ArrayList <ItemCart> elenco;
     private double prezzo;
	 
     public Carrello() {
		elenco=new ArrayList <ItemCart>();
		prezzo=0.0;
	 }

	 public double getPrezzo() {
		 return prezzo;
	 }

	 public void setPrezzo(double prezzo) {
		 this.prezzo = prezzo;
	 }

	 public ArrayList<ItemCart> getElenco() {
		 return elenco;
	 }

	 public void setElenco(ArrayList<ItemCart> elenco) {
		 this.elenco = elenco;
	 }
     
	 public void aggiungiProdotto(Prodotto p, int q) {
	        for (ItemCart item : elenco) {
	            if (item.getP().getNome().equalsIgnoreCase(p.getNome())) {
	                item.setQta(item.getQta() + q);
	                calcolaPrezzo();
	                return;
	            }
	        }
	        elenco.add(new ItemCart(p, q));
	        calcolaPrezzo();
	    }
	 
	    public void calcolaPrezzo() {
	        this.prezzo = 0.0;
	        for (ItemCart item : elenco) {
	            this.prezzo += item.getTotaleI();
	        }
	    }
	    
	    public void svuota() {
	        elenco.clear();
	        prezzo = 0.0;
	    }
     
     
     
}
