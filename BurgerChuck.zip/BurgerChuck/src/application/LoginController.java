package application;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;


public class LoginController {
	    MiaClasse cl= new MiaClasse();
	    int tentativi=6;
	    

	    @FXML
	    private ToggleButton button;

	    @FXML
	    private Label label;

	    @FXML
	    private TextField password;

	    @FXML
	    private PasswordField passwordH;
    
    @FXML
    void accedi(ActionEvent event) {
    	if(new File("tentativi.txt").exists()) {
    	String uR=cl.leggiFileUltimaRiga("tentativi.txt");
    	LocalDateTime t=null;
    	if(uR.equals("")) {
    		
    	}else if(!uR.contains("_")) {
    		uR=uR.trim();
    		if(!uR.contains("successo"))t= LocalDateTime.parse(uR);
    		else tentativi=6;
    	}else t=LocalDateTime.parse(uR.split("_")[1].trim());
    	if(!uR.contains("successo")) {
    		if(t != null && !uR.equals("") && t.until(LocalDateTime.now(),ChronoUnit.MINUTES)<30 && tentativi==0) {
        		cl.Msg_Warning("Tentativi terminati", "Hai finito i tentativi di accesso", "Aspetta e riprova !!!!");
        		return;
        	}else if (t != null && !uR.equals("")&& t.until(LocalDateTime.now(),ChronoUnit.MINUTES)>=30){
        		tentativi=6;
        	}
    	}
    	
    	}else {
    		try {
				new File("tentativi.txt").createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
        String pf;
        if(button.isSelected()) pf=password.getText();
        else pf=passwordH.getText();
        if(pf.equals(p)) {
           try {
        	   cl.scriviFile("tentativi.txt","Operazione eseguita con successo");
        	   FXMLLoader loader = new FXMLLoader(getClass().getResource("Main.fxml"));
        	   Pane view = loader.load();
               MainController controller = loader.getController();
               Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
               Scene scene = new Scene(view);
               stage.setScene(scene);
               stage.setTitle("ChuckBurger");
               stage.show();
               
           }catch(Exception e ) {
        	   e.printStackTrace();
           }
    		
        }else {
        	tentativi--;
        	password.setText("");
        	passwordH.setText("");
        	cl.Msg_Errore("Errore", "Password Errata riprova", "Rinserisci la password! Hai altri "+tentativi+" tentativi");
        	if(tentativi == 0) {
        		cl.scriviFile("tentativi.txt", LocalDateTime.now()+"");
        		return;
        	}
        	cl.scriviFile("tentativi.txt", tentativi+"_"+LocalDateTime.now());
        }
    }

    @FXML
    void visibilitaPassword(ActionEvent event) {
        if(button.isSelected()) {
        	button.setText("\uD83D\uDE48");
        	password.setText(passwordH.getText());
        	password.setVisible(true);
        	password.setManaged(true);
        	passwordH.setVisible(false);
        	passwordH.setManaged(false);
        	password.requestFocus();
        	password.positionCaret(password.getText().length());
        }else {
        	button.setText("\uD83D\uDC41");
        	passwordH.setText(password.getText());
        	passwordH.setVisible(true);
        	passwordH.setManaged(true);
        	password.setVisible(false);
        	password.setManaged(false);
        	passwordH.requestFocus();
        	passwordH.positionCaret(passwordH.getText().length());
        }
    }
    

    @FXML
    void initialize() {
        button.setText("\uD83D\uDC41");
        password.setVisible(false);
        password.setManaged(false);
		Timeline orologio = new Timeline(
			new KeyFrame(Duration.seconds(1), event -> {
				label.setText(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))+"\nBenvenuto");
			})
		);
		orologio.setCycleCount(Timeline.INDEFINITE);
		orologio.play();
			try {
				if(!new File("tentativi.txt").exists()) new File("tentativi.txt").createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        String c= cl.leggiFileUltimaRiga("tentativi.txt");
        if(c.equals("")) {
        	tentativi=6;
        	return;
        }
        c=c.trim();
        if(c.contains("successo")) tentativi=6;
        else tentativi= c.contains("_") && LocalDateTime.parse(c.split("_")[1].trim()).until(LocalDateTime.now(),ChronoUnit.MINUTES)>=30 ? 6:c.contains("_") && LocalDateTime.parse(c.split("_")[1].trim()).until(LocalDateTime.now(),ChronoUnit.MINUTES)<30?Integer.parseInt(c.split("_")[0].trim()):LocalDateTime.parse(c).until(LocalDateTime.now(), ChronoUnit.MINUTES)<30?0:6;
    }
    
    
    
    private String p="InterMerda220522";

}
