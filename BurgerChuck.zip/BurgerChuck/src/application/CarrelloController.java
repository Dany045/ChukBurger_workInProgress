package application;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class CarrelloController {
	
	@FXML 
	private VBox listaElementiCarrello;
	
    @FXML 
    private Label Totale;
    private Carrello carrello = new Carrello();
    private MiaClasse cl = new MiaClasse();
    private static int nOrdini = 1;
    
    void aggiornaCarrello() {
    	listaElementiCarrello.getChildren().clear();
        if (carrello == null || carrello.getElenco().isEmpty()) {
            Label vuoto = new Label("Il carrello è vuoto. Aggiungi qualche prodotto!");
            vuoto.setStyle("-fx-font-style: italic; -fx-text-fill: #95a5a6;");
            listaElementiCarrello.getChildren().add(vuoto);
            Totale.setText("€ 0.00");
            return;
        }
        for (ItemCart item : carrello.getElenco()) {
            HBox riga = new HBox();
            riga.setSpacing(15);
            riga.setStyle("-fx-background-color: white; -fx-padding: 10; -fx-background-radius: 10; -fx-alignment: center-left;");
            Label info = new Label(item.getP().getNome() + " x" + item.getQta());
            info.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
            info.setPrefWidth(220);
            Label prezzo = new Label(String.format("€ %.2f", item.getTotaleI()));
            prezzo.setStyle("-fx-text-fill: #d35400; -fx-font-weight: bold;");
            prezzo.setPrefWidth(80);
            Button btnElimina = new Button("❌");
            btnElimina.setStyle("-fx-background-color: transparent; -fx-text-fill: #e74c3c; -fx-cursor: hand;");
            btnElimina.setOnAction(e -> {
                carrello.getElenco().remove(item);
                carrello.calcolaPrezzo();
                String tCarrello = "";
                for(ItemCart rimasto : carrello.getElenco()) {
                	tCarrello += rimasto.getP().toString() + "_" + rimasto.getQta() + "\n";
                }
                cl.scriviFileB1("carrello.txt", tCarrello.trim());
                aggiornaCarrello(); 
            });
            riga.getChildren().addAll(info, prezzo, btnElimina);
            listaElementiCarrello.getChildren().add(riga);
        }
        Totale.setText(String.format("€ %.2f", carrello.getPrezzo()));
    }
    
    @FXML
    void svuotaCarrello(ActionEvent event) {
        if (carrello != null && !carrello.getElenco().isEmpty()) {
            carrello.svuota();
            cl.scriviFileB1("carrello.txt", "");
            aggiornaCarrello();
        }
    }
    
    @FXML
    void initialize() {
        carrello.getElenco().clear(); 
        String content = leggiTutto("carrello.txt");
        
        if (content != null && !content.trim().isEmpty()) {
            inizializzaCarrello(content);
        }
        aggiornaCarrello();
    }
    @FXML
    void inizializzaCarrello(String content) {
        String[] v1 = content.split("\n");
        for (String riga : v1) {
            if (riga.trim().isEmpty()) continue;
            try {
                String[] ic = riga.split("_");
                if (ic.length < 2) continue;
                
                String[] campo = ic[0].split(";");
                int quantita = Integer.parseInt(ic[1].trim());
                String tipo = campo[0].trim().toLowerCase();
                if (tipo.equals("panino")) {
                    carrello.getElenco().add(new ItemCart(new Panino(campo[1].trim(), 
                        Double.parseDouble(campo[2].trim()), 
                        Integer.parseInt(campo[3].trim()), 
                        campo[4].trim(), 
                        campo[5].trim(), 
                        Integer.parseInt(campo[6].trim())
                    ), quantita));
                } else if (tipo.equals("bibita")) {
                    carrello.getElenco().add(new ItemCart(new Bibita(
                        campo[1].trim(), 
                        Double.parseDouble(campo[2].trim()), 
                        Integer.parseInt(campo[3].trim()), 
                        campo[4].trim(), 
                        Double.parseDouble(campo[5].trim())
                    ), quantita));
                } else if (tipo.equals("sfiziosita")) {
                    String valoreSfiziosita = campo[5].trim();
                    if (valoreSfiziosita.isEmpty() && campo.length > 6) {
                        valoreSfiziosita = campo[6].trim();
                    }

                    carrello.getElenco().add(new ItemCart(new Sfiziosita(campo[1].trim(), Double.parseDouble(campo[2].trim()), 
                        Integer.parseInt(campo[3].trim()), 
                        campo[4].trim(), 
                        Integer.parseInt(valoreSfiziosita)
                    ), quantita));
                } else {
                    System.out.println("⚠️ Tipo prodotto sconosciuto: " + campo[0]);
                }
            } catch (Exception e) {
                System.out.println("❌ Errore nella riga carrello: " + riga);
                e.printStackTrace();
            }
        }
        carrello.calcolaPrezzo();
    }
    
    String leggiTutto(String path) {
		String content = "";
		try(BufferedReader read = new BufferedReader(new FileReader(path))){
			String riga;
			while((riga = read.readLine()) != null) content += riga + "\n";
			return content;
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}
	}
    
    @FXML
    void pagamento(ActionEvent event) {
        if (carrello == null || carrello.getElenco().isEmpty()) {
            cl.Msg_Info("Errore", "Impossibile procedere", "Aggiungi almeno un prodotto prima di pagare!");
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("popupStampa.fxml"));
            Parent root = loader.load();
            ScontrinoController scontrinoController = loader.getController();
            Ordine o = new Ordine(carrello, LocalDateTime.now(), nOrdini++);
            scontrinoController.setScontrino(o.scontrino());
            Stage popupStage = new Stage();
            popupStage.initModality(Modality.APPLICATION_MODAL);
            popupStage.setTitle("Scontrino Finale");
            popupStage.setScene(new Scene(root));
            popupStage.setResizable(false);
            popupStage.showAndWait();
            cl.scriviFile("ordini.txt", o.toString());
            carrello.svuota();
            cl.scriviFileB1("carrello.txt", "");
            tornaMenu(event);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    void tornaMenu(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
}