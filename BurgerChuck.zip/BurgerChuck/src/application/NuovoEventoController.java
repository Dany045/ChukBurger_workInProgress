package application;

import java.time.LocalDate;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class NuovoEventoController {
	@FXML 
	private DatePicker datePicker;
	
    @FXML 
    private TextField Ora;
    
    @FXML 
    private TextField Minuti;
    
    @FXML 
    private TextField Descrizione;

    private MiaClasse cl= new MiaClasse();
    
    @FXML
    void initialize() {
        if (datePicker != null) {
            datePicker.setValue(LocalDate.now()); 
        }
    }
	
	@FXML
    void salva(ActionEvent event) {
        LocalDate data = datePicker.getValue();
        String ora = Ora.getText().trim();
        String minuti = Minuti.getText().trim();
        String desc = Descrizione.getText().trim();
        
        if (ora.isEmpty() || minuti.isEmpty() || desc.isEmpty() || data == null) {
        	cl.Msg_Info("Campi vuoti", "Sono presenti dei campi vuoti ","Compila tutti i campi!" );
            return;
        }
        
        try {
        	if(Integer.parseInt(ora)<0 || Integer.parseInt(ora)>23 || Integer.parseInt(minuti)<0 || Integer.parseInt(minuti)>59) {
            	cl.Msg_Info("Dati errati", "Sono presenti dei valori errati ","L'ora va da 0 a 23 !!! I minuti vanno da 0 a 59 !!!" );
                return;
            }
        	
        }catch(Exception e) {
        	cl.Msg_Info("Dati errati", "Formato orario non valido", "Inserisci solo numeri interi nei campi Ora e Minuti!");
            return;
        	
        }
        String txt = data.getDayOfMonth() + "/" + data.getMonthValue() + "/" + data.getYear() + "-" + ora + ":" + minuti + "-" + desc;
        cl.scriviFile("eventi.txt", txt);
        cl.Msg_Info("Successo", "Evento Salvato", "L'evento � stato aggiunto con successo.");
        chiudiFinestra(event);
    }

    @FXML
    void annulla(ActionEvent event) {
        chiudiFinestra(event);
    }

    private void chiudiFinestra(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
}
	

