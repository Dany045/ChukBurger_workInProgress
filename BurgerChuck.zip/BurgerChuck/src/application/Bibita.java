package application;

public class Bibita extends Prodotto{
        
	  private double capacita;

	  public Bibita(String nome, double prezzo, int apportoCalorico, String percorsoImg, double capacita) {
		super(nome, prezzo, apportoCalorico, percorsoImg);
		this.capacita = capacita;
	  }
	  
	  public String Tipo() {
		  return "Bibita";
	  }

	  @Override
	  public String toString() {
		return "Bibita;" + nome + ";" + prezzo + ";"+apportoCalorico+";" + percorsoImg + ";"
				+ capacita ;
	  }

	  public double getCapacita() {
		  return capacita;
	  }

	  public void setCapacita(double capacita) {
		  this.capacita = capacita;
	  }
	  
	  
	  
	  
}
