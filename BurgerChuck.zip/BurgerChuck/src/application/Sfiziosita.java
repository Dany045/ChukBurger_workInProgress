package application;

public class Sfiziosita extends Prodotto {

	private int peso;

	public Sfiziosita(String nome, double prezzo, int apportoCalorico, String percorsoImg, int peso) {
		super(nome, prezzo, apportoCalorico, percorsoImg);
		this.peso = peso;
	}
	public String Tipo() {
		  return "Sfiziosita";
	  }
	@Override
	public String toString() {
		return "Sfiziosita;" + nome + ";" + prezzo + ";" + apportoCalorico+";" +percorsoImg+";"+ ";" + peso;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

}
