package application;


public abstract class Prodotto {
	
        protected String nome;
        protected double prezzo;
        protected int apportoCalorico;
        protected String percorsoImg;
        
		public Prodotto(String nome, double prezzo, int apportoCalorico, String percorsoImg) {
			this.nome = nome;
			this.prezzo = prezzo;
			this.apportoCalorico = apportoCalorico;
			this.percorsoImg = percorsoImg;
		}
	    public abstract String Tipo();
	    public abstract String toString();

		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		public double getPrezzo() {
			return prezzo;
		}

		public void setPrezzo(double prezzo) {
			this.prezzo = prezzo;
		}

		public int getApportoCalorico() {
			return apportoCalorico;
		}
		

		public void setApportoCalorico(int apportoCalorico) {
			this.apportoCalorico = apportoCalorico;
		}

		public String getPercorsoImg() {
			return percorsoImg;
		}

		public void setPercorsoImg(String percorsoImg) {
			this.percorsoImg = percorsoImg;
		}
	    
	    
	    
}
