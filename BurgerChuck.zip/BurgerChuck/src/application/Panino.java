package application;

public class Panino extends Prodotto {

	private String ingredienti;
	private int peso;

	public Panino(String nome, double prezzo, int apportoCalorico, String percorsoImg, String ingredienti, int peso) {
		super(nome, prezzo, apportoCalorico, percorsoImg);
		this.ingredienti = ingredienti;
		this.peso = peso;
	}
	public String Tipo() {
		  return "Panino";
	  }
	@Override
	public String toString() {
		return "Panino;" + nome + ";" + prezzo + ";" + apportoCalorico + ";" + percorsoImg + ";" + ingredienti + ";"
				+ peso;
	}

	public String getIngredienti() {
		return ingredienti;
	}

	public void setIngredienti(String ingredienti) {
		this.ingredienti = ingredienti;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

}
