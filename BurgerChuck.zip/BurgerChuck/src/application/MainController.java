package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.LocalDateTime;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class MainController {
	private ArrayList <Prodotto> elenco;
	private MiaClasse cl= new MiaClasse ();
	private String categoria;
	
	@FXML
    private Label time;
	
	@FXML
	private VBox listaEventi;
	
	@FXML 
	private StackPane badgeCarrello; 
    
	@FXML 
    private Label Contatore;   
	
	@FXML 
	private VBox listaProdotti;
	
	@FXML 
	private Label Tipo;
	
	@FXML
	void apriAggiungiProdotto(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("AggiungiProdotto.fxml"));
			Parent root = loader.load();
			Stage pStage = new Stage();
			pStage.initModality(Modality.APPLICATION_MODAL);
			pStage.setTitle("Aggiungi Prodotto");
			pStage.setScene(new Scene(root));
			pStage.setResizable(false);
			pStage.showAndWait();
			elenco.clear();
			inizializzaFile("prodotti.txt");
			mostraProdottiMenu(categoria);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
    
	void mostraProdottiMenu(String categoria) {
	    this.categoria = categoria;
	    listaProdotti.getChildren().clear(); 
	    if(categoria.equalsIgnoreCase("panino")) Tipo.setText("Panini");
	    else if(categoria.equalsIgnoreCase("bibita")) Tipo.setText("Bibite");
	    else if(categoria.equalsIgnoreCase("sfiziosita")) Tipo.setText("Sfiziosità");

	    for (Prodotto p : elenco) {
	        boolean appartiene = false;
	        if (categoria.equalsIgnoreCase("panino") && p instanceof Panino) appartiene = true;
	        else if (categoria.equalsIgnoreCase("bibita") && p instanceof Bibita) appartiene = true;
	        else if (categoria.equalsIgnoreCase("sfiziosita") && p instanceof Sfiziosita) appartiene = true;
	        if (!appartiene) continue;
            try {
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("Card.fxml"));
	            VBox card = loader.load();
	            CardController cardController = loader.getController();
	            cardController.impostaDati(p, this);
	            listaProdotti.getChildren().add(card);

	        } catch (IOException e) {
	            System.out.println("Errore nel caricamento del file ProdottoCard.fxml");
	            e.printStackTrace();
	        }
	    }
	}
    public void aggiornaBadgeCarrello() {
        String content = leggiTutto("carrello.txt");
        if (content.trim().isEmpty()) {
            badgeCarrello.setVisible(false);
            return;
        }
        int q = 0;
        String[] righe = content.split("\n");
        for (String riga : righe) {
            if (riga.trim().isEmpty()) continue;
            try {
                String[] ic = riga.split("_");
                if (ic.length > 1) {
                    q += Integer.parseInt(ic[1].trim());
                }
            } catch (Exception e) {
            	e.printStackTrace();
            }
        }
        if (q == 0) {
            badgeCarrello.setVisible(false);
        } else {
            badgeCarrello.setVisible(true);
            Contatore.setText(String.valueOf(q));
        }
    }
    
    @FXML
    void filtraPanini(ActionEvent event) {
        mostraProdottiMenu("panino");
    }

    @FXML
    void filtraSfiziosita(ActionEvent event) {
        mostraProdottiMenu("sfiziosita");
    }

    @FXML
    void filtraBibite(ActionEvent event) {
        mostraProdottiMenu("bibita");
    }
	
	@FXML
	void apriScenaNuovoEvento() {
	    try {
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("NuovoEvento.fxml"));
	        Parent root = loader.load();
	        NuovoEventoController controller = loader.getController();
	        Stage eStage = new Stage();
	        eStage.initModality(Modality.APPLICATION_MODAL);
	        eStage.setTitle("Nuovo Evento");
	        eStage.setScene(new Scene(root));
	        eStage.setResizable(false);
	        eStage.showAndWait();
	        aggiornaLabel();
	        mostraProdottiMenu(categoria);
	        
	        
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	@FXML
	void apriCarrello(ActionEvent event) {
	    try {
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrello.fxml"));
	        Parent root = loader.load();
	        CarrelloController controller = loader.getController();
	        Stage carrelloStage = new Stage();
	        carrelloStage.initModality(Modality.APPLICATION_MODAL);
	        carrelloStage.setTitle("Carrello");
	        carrelloStage.setScene(new Scene(root));
	        carrelloStage.setResizable(false);
	        carrelloStage.showAndWait();
	        aggiornaBadgeCarrello(); 
	        mostraProdottiMenu(categoria);

	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
    void aggiornaLabel() {
    	if(!new File("eventi.txt").exists()) {
			try {
				new File ("eventi.txt").createNewFile() ;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	listaEventi.getChildren().clear();
    	String content=leggiTutto("eventi.txt");
    	if(content.equals("")) {
    		 listaEventi.getChildren().add(new Label ("Non sono presenti eventi in calendario "));
			 return;
		 }
    	String [] riga=content.split("\n");
    	int c=0;
    	for(int i=0;i<riga.length;i++) {
    		if(riga[i].trim().isEmpty()) continue;
    		try {
    		String campo[]=riga[i].split("-");
    		LocalDate l = LocalDate.parse(campo[0].trim(), java.time.format.DateTimeFormatter.ofPattern("d/M/yyyy"));
    		LocalDate o=LocalDate.now();
    		if(l.equals(o)) {
    	    c++;
    		Label label = new Label(riga[i]);
            label.setStyle("-fx-background-color: #f0f0f0; -fx-padding: 5; -fx-background-radius: 5; -fx-font-size: 11px;");
            label.setPrefWidth(315);
            label.setWrapText(true);
            listaEventi.getChildren().add(label);
    		}
    		}catch(Exception e) {
    			System.out.println("Salto riga evento corrotto: " + riga[i]+"Sistema!!!");
    		}
    	}
    	if(c==0) listaEventi.getChildren().add(new Label ("Non sono presenti eventi oggi "));
    	
    }
	@FXML
    void initialize() {
		elenco=new ArrayList <Prodotto>();
		categoria="Panino";
		Timeline orologio = new Timeline(
			new KeyFrame(Duration.seconds(1), event -> {
				time.setText(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));
			})
		);
		orologio.setCycleCount(Timeline.INDEFINITE);
		orologio.play();
		aggiornaLabel();
		if(!new File ("prodotti.txt").exists()) {
			try {
				new File("prodotti.txt").createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		inizializzaFile("prodotti.txt");
		aggiornaBadgeCarrello();
	}
	
	String leggiTutto(String path) {
		String content = "";
		  try(BufferedReader read=new BufferedReader(new FileReader(path))){
			  String riga;
			  while((riga=read.readLine())!=null) content+=riga+"\n";
			  return content;
		  }catch(Exception e) {
			  e.printStackTrace();
			  return "";
		  }
	}
	
	public void inizializzaFile(String path) {
	    try (BufferedReader br = new BufferedReader(new FileReader(path))) {
	        String riga;
	        while ((riga = br.readLine()) != null) {
	            String[] c = riga.trim().split(";");
	            if (riga.trim().isEmpty() || c.length < 5) continue; 
	            try {
	                if (c[0].equalsIgnoreCase("panino") && c.length >= 7) 
	                    elenco.add(new Panino(c[1], Double.parseDouble(c[2]), Integer.parseInt(c[3]), c[4], c[5], Integer.parseInt(c[6])));
	                else if (c[0].equalsIgnoreCase("bibita") && c.length >= 6) 
	                    elenco.add(new Bibita(c[1], Double.parseDouble(c[2]), Integer.parseInt(c[3]), c[4], Double.parseDouble(c[5])));
	                else if (c[0].equalsIgnoreCase("sfiziosita") && c.length >= 6) 
	                    elenco.add(new Sfiziosita(c[1], Double.parseDouble(c[2]), Integer.parseInt(c[3]), c[4], Integer.parseInt(c[5])));
	            } catch (Exception e) { System.out.println("⚠️ Riga errata: " + riga); }
	        }
	    } catch (IOException e) { System.out.println("❌ Errore file: " + e.getMessage()); }
	}
	 
}
