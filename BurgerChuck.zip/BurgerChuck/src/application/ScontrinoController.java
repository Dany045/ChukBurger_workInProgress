package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.TextArea;
import javafx.print.PrinterJob;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ScontrinoController {

    @FXML private TextArea Scontrino;

    public void setScontrino(String scontrinoTesto) {
        Scontrino.setText(scontrinoTesto);
    }

    @FXML
    void chiudi(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    @FXML
    void stampa(ActionEvent event) {
        PrinterJob job = PrinterJob.createPrinterJob();
        if (job != null) {
            if (job.showPrintDialog((Stage) ((Node) event.getSource()).getScene().getWindow())) {
                Text stampa = new Text(Scontrino.getText());
                stampa.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 10px;");
                if (job.printPage(stampa)) {
                    job.endJob();
                    System.out.println("Stampa completata con successo!");
                } else {
                    System.out.println("Errore durante l'invio alla stampante.");
                }
            }
        } else {
            System.out.println("Nessuna stampante trovata sul sistema.");
        }
    }
}
