package application;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class CardController {
    @FXML 
    private Label lblNome;
    
    @FXML 
    private Label lblDescrizione;
    
    @FXML
    private Label lblPrezzo;
    
    @FXML
    private Label lblQta;
    
    @FXML
    private ImageView imgProdotto;
    
    @FXML
    private Button btnMeno;
    
    @FXML
    private
    Button btnPiu;
    
    @FXML
    private Button btnAggiungi;

    private Prodotto prodotto;
    private MiaClasse cl = new MiaClasse();
    private MainController mainController; 

    public void impostaDati(Prodotto p, MainController mainCtrl) {
        this.prodotto = p;
        this.mainController = mainCtrl;
        lblNome.setText(p.getNome());
        lblPrezzo.setText(String.format("� %.2f", p.getPrezzo()));
        if (p instanceof Panino) lblDescrizione.setText(((Panino) p).getIngredienti());
        else if (p instanceof Bibita) lblDescrizione.setText("Capacit�: " + ((Bibita) p).getCapacita() + "L");
        else if (p instanceof Sfiziosita) lblDescrizione.setText("Peso: " + ((Sfiziosita) p).getPeso() + "g");
        try {
            imgProdotto.setImage(new Image(getClass().getResourceAsStream(p.getPercorsoImg())));
        } catch (Exception e) {
            System.out.println("Immagine non trovata per " + p.getNome());
        }
        btnPiu.setOnAction(e -> {
            int q = Integer.parseInt(lblQta.getText());
            lblQta.setText(String.valueOf(q + 1));
        });
        btnMeno.setOnAction(e -> {
            int q = Integer.parseInt(lblQta.getText());
            if (q > 1) lblQta.setText(String.valueOf(q - 1));
        });
        btnAggiungi.setOnAction(e -> {
            int qta = Integer.parseInt(lblQta.getText());
            cl.scriviFile("carrello.txt", prodotto.toString() + "_" + qta);
            lblQta.setText("1");
            mainController.aggiornaBadgeCarrello(); 
        });
    }
}